# a4
Source code for the A4 plugin.

# Download
Download it at [PyPI](https://pypi.org/project/a4/) or type this command in your terminal:
```
pip install a4
```
